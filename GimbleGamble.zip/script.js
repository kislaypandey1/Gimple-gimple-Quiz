
function startGame() {
  alert('Game started!');
}
